package pl.polsl.orderadoctor.model;

public enum VisitState {

    UTWORZONA, ZATWIERDZONA, ZAKONCZONA, OCENIONA

}
