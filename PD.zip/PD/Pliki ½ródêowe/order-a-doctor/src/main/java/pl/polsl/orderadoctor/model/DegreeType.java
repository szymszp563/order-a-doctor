package pl.polsl.orderadoctor.model;

public enum DegreeType {

    lek, dr, prof
}
