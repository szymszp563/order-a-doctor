package pl.polsl.orderadoctor.model;

public enum AccountType {

    GOOGLE, FACEBOOK
}
